package com.ketan.bsm.enums;

public enum AdminType {
    OWNER,GUEST;
}
