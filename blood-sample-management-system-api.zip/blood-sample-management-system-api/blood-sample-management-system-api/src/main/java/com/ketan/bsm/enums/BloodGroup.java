package com.ketan.bsm.enums;

public enum BloodGroup {
    A_POSITIVE,B_POSITIVE,O_POSITIVE,
    AB_POSITIVE,AB_NEGATIVE,
    A_NEGETIVE,B_NEGETIVE,O_NEGETIVE;

}
