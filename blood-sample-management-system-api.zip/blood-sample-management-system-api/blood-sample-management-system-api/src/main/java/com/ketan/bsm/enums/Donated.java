package com.ketan.bsm.enums;

public enum Donated {
}
