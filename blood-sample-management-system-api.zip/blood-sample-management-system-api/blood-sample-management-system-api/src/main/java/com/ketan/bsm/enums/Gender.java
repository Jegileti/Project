package com.ketan.bsm.enums;

public enum Gender {
    MALE,FEMALE,OTHERS;
}
