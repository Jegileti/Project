package com.ketan.bsm.enums;

public enum OrganizationType {
    HOSPITAL,BLOODBANK;
}
