package com.ketan.bsm.enums;

public enum Role {
    USER,
    OWNER_ADMIN,
    GUEST_ADMIN;
}
