package com.ketan.bsm.repository;

import com.ketan.bsm.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonationRepository extends JpaRepository<Address,Integer> {
}
