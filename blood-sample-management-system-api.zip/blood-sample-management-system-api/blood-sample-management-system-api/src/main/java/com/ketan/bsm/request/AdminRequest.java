package com.ketan.bsm.request;

public class AdminRequest {
}
