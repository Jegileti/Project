package com.ketan.bsm.service;

import com.ketan.bsm.entity.DonationRequest;
import com.ketan.bsm.request.DonationRequestRequest;
import com.ketan.bsm.response.DonationRequestResponse;

public interface DonationService {

}
