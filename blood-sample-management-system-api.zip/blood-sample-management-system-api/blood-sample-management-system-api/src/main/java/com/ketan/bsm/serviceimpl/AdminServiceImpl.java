package com.ketan.bsm.serviceimpl;

public class AdminServiceImpl {
}
