package com.ketan.bsm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodSampleManagementSystemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
